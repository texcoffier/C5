/* The expected C program */

